<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Laravel\Sanctum\HasApiTokens;

class User extends Model
{
    use HasFactory, HasApiTokens;

    protected $fillable = [
        
        'applicant_name',
        'last_name',
        'phone_number',
        'cnic',
        'email_address',
        'password',
        'name_of_vswa',
        'vswa_email',
        'short_name',
        'vswa_phone',
        'thematic_id',
        'vswa_hq_id'
    ];

    /**
     * Get the thematic area associated with the user.
     */
    public function thematicArea()
    {
        return $this->belongsTo(ThematicArea::class, 'thematic_id');
    }

    /**
     * Get the VSWA headquarter associated with the user.
     */
    public function vswaHeadQuarter()
    {
        return $this->belongsTo(VswaHeadQuarter::class, 'vswa_hq_id');
    }

    // In User model
public function thematicAreas()
{
    return $this->belongsToMany(ThematicArea::class);
}
}
