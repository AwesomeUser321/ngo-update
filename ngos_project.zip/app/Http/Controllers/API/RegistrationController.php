<?php

namespace App\Http\Controllers\API;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class RegistrationController extends Controller
{
    
    
    public function register(Request $request)
    {
        // Validation rules
        $validator = Validator::make($request->all(), [
            'applicant_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'phone_number' => 'required|string|max:15',
            'cnic' => 'required|string|unique:users,cnic|max:15',
            'email_address' => 'required|string|email|max:255|unique:users,email_address',
            'password' => 'required|string|min:8|confirmed',
            'name_of_vswa' => 'required|string|max:255',
            'vswa_email' => 'required|string|email|max:255|unique:users,vswa_email',
            'short_name' => 'required|string|max:255',
            'vswa_phone' => 'required|string|max:15',
            'vswa_hq_id' => 'required|exists:vswa_head_quarters,id',
            'thematic_ids' => 'required|array|exists:thematic_areas,id', // Array of thematic IDs
        ]);
    
        // If validation fails, return error response
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
    
        // Create the user
        $user = User::create([
            'applicant_name' => $request->applicant_name,
            'last_name' => $request->last_name,
            'phone_number' => $request->phone_number,
            'cnic' => $request->cnic,
            'email_address' => $request->email_address,
            'password' => Hash::make($request->password),
            'name_of_vswa' => $request->name_of_vswa,
            'vswa_email' => $request->vswa_email,
            'short_name' => $request->short_name,
            'vswa_phone' => $request->vswa_phone,
            'vswa_hq_id' => $request->vswa_hq_id,
        ]);
    
        // Attach thematic areas to the user
        $user->thematicAreas()->attach($request->thematic_ids);
    
        // Return success response with user data
        return response()->json([
            'message' => 'User registered successfully',
            'user' => $user->load('thematicAreas')  // Load thematic areas with user data
        ], 201);
    }
    public function login(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'vswa_email' => 'required|email|max:255',
            'password' => 'required|string|min:8',
        ]);

        // Find user by vswa_email
        $user = User::where('vswa_email', $request->vswa_email)->first();

        // Check if user exists and password matches
        if ($user && Hash::check($request->password, $user->password)) {
            // Generate API token
            $token = $user->createToken('API Token')->plainTextToken;

            // Return success response with token and user details (excluding password)
            return response()->json([
                'message' => 'Login successful',
                'token' => $token,
                'user' => $user->makeHidden(['password']),  // Hide password from response
            ], 200);
        }

        // Return error response if login fails
        return response()->json(['message' => 'Invalid credentials'], 401);
    }
}

   //logout
     
//    public function logout(Request $request)
//    {
//        // Revoke the token that was used to authenticate the current request
//        $request->user()->currentAccessToken()->delete();

//        return response()->json([
//            'message' => 'Logged out successfully'
//        ], 200);
//    }

