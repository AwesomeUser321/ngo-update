<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('applicant_name');
            $table->string('last_name');
            $table->string('phone_number');
            $table->string('cnic')->unique();  // CNIC should be unique
            $table->string('email_address')->unique();
            $table->string('password');
            $table->string('name_of_vswa');
            $table->string('vswa_email')->unique();
            $table->string('short_name');
            $table->string('vswa_phone');
            $table->foreignId('thematic_id')->default(1)->constrained('thematic_areas')->onDelete('cascade');
            $table->foreignId('vswa_hq_id')->constrained('vswa_head_quarters')->onDelete('cascade');
            $table->timestamps();
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
